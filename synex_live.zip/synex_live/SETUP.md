# 🚀 Synex Live — Setup Guide

## Prerequisites
- Flutter 3.x installed
- Firebase account
- Android Studio / VS Code

---

## Step 1 — Firebase Setup

1. Go to https://console.firebase.google.com
2. Create a new project: **synex-live**
3. Enable these services:
   - **Authentication** → Email/Password + Google
   - **Firestore Database** → Start in production mode
   - **Cloud Messaging** (FCM)
   - **Storage** (for profile photos)

---

## Step 2 — Add Firebase to Flutter

Install FlutterFire CLI:
```bash
dart pub global activate flutterfire_cli
```

Run configuration:
```bash
flutterfire configure
```
This auto-generates `lib/firebase_options.dart` with your credentials.

---

## Step 3 — Android Setup

1. Download `google-services.json` from Firebase Console
2. Place it at: `android/app/google-services.json`
3. In `android/app/build.gradle`, set your package name:
   ```
   applicationId "com.yourname.synex_live"
   ```

---

## Step 4 — Google Sign-In Setup

1. In Firebase Console → Authentication → Sign-in method → Google → Enable
2. Add your SHA-1 fingerprint:
```bash
cd android && ./gradlew signingReport
```
3. Copy SHA-1 → Firebase Console → Project Settings → Your App → Add fingerprint

---

## Step 5 — Firestore Rules

In Firebase Console → Firestore → Rules, paste contents of `firestore.rules`

---

## Step 6 — Install & Run

```bash
flutter pub get
flutter run
```

---

## Firestore Data Structure

```
users/
  {uid}: { name, email, photoUrl, bio, fcmToken, ... }

lives/
  {liveId}: { hostId, hostName, title, speakers[], blockedUsers[], mutedSpeakers[], isLive, viewerCount, startedAt }

live_chats/
  {liveId}/messages/
    {msgId}: { userId, userName, message, timestamp, isHost }

live_requests/
  {liveId}: {
    {userId}: { name, status: "pending|accepted|rejected", requestedAt }
  }

signaling/
  {liveId}/connections/
    {callerId_calleeId}: { offer, answer }
  {liveId}/ice_candidates/
    {uid}/{peerId}/{docId}: { candidate, sdpMid, sdpMLineIndex }
```

---

## WebRTC Notes

- Current impl: P2P mesh (good for ≤6 speakers)
- For production scale (100+ concurrent), use SFU servers:
  - **LiveKit** (open source, self-hosted or cloud)
  - **Daily.co** API
  - **Agora.io** SDK
- TURN servers needed for NAT traversal in production

---

## FCM Push Notifications

To send actual push notifications, deploy a Cloud Function:

```javascript
// functions/index.js
const functions = require('firebase-functions');
const admin = require('firebase-admin');
admin.initializeApp();

exports.sendNotification = functions.firestore
  .document('notifications/{notifId}')
  .onCreate(async (snap) => {
    const data = snap.data();
    if (data.sent || !data.targetFcmToken) return;
    await admin.messaging().send({
      token: data.targetFcmToken,
      notification: { title: 'Synex Live', body: data.message },
      data: { liveId: data.liveId, type: data.type },
    });
    await snap.ref.update({ sent: true });
  });
```

---

## Folder Structure

```
lib/
├── main.dart
├── firebase_options.dart
├── screens/
│   ├── splash_screen.dart
│   ├── home_screen.dart
│   ├── live_screen.dart        ← Main live room
│   ├── go_live_screen.dart     ← Host start live
│   ├── profile_screen.dart
│   └── auth/
│       ├── login_screen.dart
│       └── signup_screen.dart
├── services/
│   ├── auth_service.dart       ← Email + Google auth
│   ├── live_service.dart       ← Firestore live ops
│   ├── webrtc_service.dart     ← WebRTC P2P
│   ├── notification_service.dart ← FCM
│   └── user_service.dart
├── models/
│   ├── user_model.dart
│   ├── live_model.dart
│   ├── chat_model.dart
│   └── live_request_model.dart
├── widgets/
│   ├── custom_button.dart
│   ├── custom_text_field.dart
│   ├── live_card.dart
│   ├── speaker_tile.dart
│   ├── chat_bubble.dart
│   ├── request_tile.dart
│   ├── user_avatar.dart
│   └── loading_shimmer.dart
└── utils/
    ├── app_theme.dart
    ├── app_constants.dart
    ├── validators.dart
    └── helpers.dart
```
